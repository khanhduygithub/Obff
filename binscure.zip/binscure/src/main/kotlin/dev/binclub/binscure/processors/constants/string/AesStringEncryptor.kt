package dev.binclub.binscure.processors.constants.string

import org.objectweb.asm.Opcodes.*
import org.objectweb.asm.Handle
import org.objectweb.asm.Type
import org.objectweb.asm.tree.*
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import java.util.Base64

// ═══════════════════════════════════════════════════════════════════════════
//  BinScure — Nâng cấp: AES-256-GCM String Encryption + InvokeDynamic
//
//  Kiến trúc:
//    • Mỗi string → mã hoá AES-256-GCM với key riêng biệt
//    • Key = SHA-256(className + methodName + stringIndex)
//    • IV  = 12 byte đầu của SHA-256(key || index)  — deterministic, không lưu
//    • Ciphertext lưu dưới dạng Base64 trong LDC constant pool
//    • Tại runtime: INVOKEDYNAMIC → bootstrap → giải mã tại chỗ, không cache
//    • Bootstrap method được nhúng dưới dạng bytecode vào decryptorClass
// ═══════════════════════════════════════════════════════════════════════════

// ─── 1. Compile-time: encrypt one string ────────────────────────────────────

data class AesEncryptedString(
    val original:   String,
    val cipherB64:  String,   // Base64(IV || ciphertext || GCM-tag)
    val keyB64:     String,   // Base64(32-byte AES key)  – embedded in bootstrap
    val className:  String,
    val methodName: String,
    val index:      Int,
    val classNode:  ClassNode,
    val methodNode: MethodNode,
    val insn:       LdcInsnNode
)

object AesStringEncryptor {

    // ── Key derivation: SHA-256(className + "|" + methodName + "|" + index) ──
    fun deriveKey(className: String, methodName: String, index: Int): ByteArray {
        val sha = MessageDigest.getInstance("SHA-256")
        sha.update(className.toByteArray(Charsets.UTF_8))
        sha.update("|".toByteArray())
        sha.update(methodName.toByteArray(Charsets.UTF_8))
        sha.update("|".toByteArray())
        sha.update(index.toString().toByteArray(Charsets.UTF_8))
        return sha.digest()  // 32 bytes → AES-256
    }

    // ── IV derivation: first 12 bytes of SHA-256(key || index) ──────────────
    fun deriveIv(key: ByteArray, index: Int): ByteArray {
        val sha = MessageDigest.getInstance("SHA-256")
        sha.update(key)
        sha.update(index.toString().toByteArray(Charsets.UTF_8))
        return sha.digest().copyOf(12)   // GCM nonce = 96 bits
    }

    // ── Encrypt: returns Base64(IV || ciphertext+tag) ────────────────────────
    fun encrypt(plaintext: String, key: ByteArray, iv: ByteArray): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        val ct = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        // Store: IV (12) || ciphertext+tag
        val blob = iv + ct
        return Base64.getEncoder().encodeToString(blob)
    }

    // ── Decrypt (mirror for verification) ───────────────────────────────────
    fun decrypt(b64: String, key: ByteArray): String {
        val blob = Base64.getDecoder().decode(b64)
        val iv   = blob.copyOf(12)
        val ct   = blob.copyOfRange(12, blob.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(ct), Charsets.UTF_8)
    }

    // ── Main entry: encrypt one LDC string ──────────────────────────────────
    fun encryptString(
        original:   String,
        className:  String,
        methodName: String,
        index:      Int,
        classNode:  ClassNode,
        methodNode: MethodNode,
        insn:       LdcInsnNode
    ): AesEncryptedString {
        val key    = deriveKey(className, methodName, index)
        val iv     = deriveIv(key, index)
        val cipher = encrypt(original, key, iv)

        // Sanity check
        val roundtrip = decrypt(cipher, key)
        check(roundtrip == original) { "AES round-trip failed for: $original" }

        return AesEncryptedString(
            original   = original,
            cipherB64  = cipher,
            keyB64     = Base64.getEncoder().encodeToString(key),
            className  = className,
            methodName = methodName,
            index      = index,
            classNode  = classNode,
            methodNode = methodNode,
            insn       = insn
        )
    }
}


// ─── 2. Runtime decryptor — bytecode generator ──────────────────────────────
//
//  Generates a synthetic class containing:
//    (a) aesDecrypt(String cipherB64, String keyB64) → String
//    (b) bootstrapDecrypt(Lookup, name, type, String cipherB64, String keyB64)
//            → ConstantCallSite  (called by INVOKEDYNAMIC)
//
//  The generated class is written as a .class resource so decompilers
//  cannot trivially follow imports back to javax.crypto.*.

object AesDecryptorClassGenerator {

    const val RUNTIME_CLASS = "dev/binclub/binscure/rt/AesStringDecryptor"
    const val DECRYPT_DESC  = "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;"
    const val BOOTSTRAP_DESC =
        "(Ljava/lang/invoke/MethodHandles\$Lookup;" +
        "Ljava/lang/String;" +
        "Ljava/lang/invoke/MethodType;" +
        "Ljava/lang/String;" +    // cipherB64
        "Ljava/lang/String;" +    // keyB64
        ")Ljava/lang/invoke/CallSite;"

    // ── Build the ClassNode ──────────────────────────────────────────────────
    fun buildClassNode(): ClassNode {
        val cn = ClassNode().apply {
            version    = V11
            access     = ACC_PUBLIC or ACC_FINAL or ACC_SYNTHETIC
            name       = RUNTIME_CLASS
            superName  = "java/lang/Object"
            signature  = null
            sourceFile = null     // strip debug info
        }

        cn.methods.add(buildAesDecryptMethod())
        cn.methods.add(buildBootstrapMethod())
        return cn
    }

    // ────────────────────────────────────────────────────────────────────────
    //  aesDecrypt(String cipherB64, String keyB64): String
    //
    //  Equivalent Java (obfuscated bytecode):
    //    byte[] blob = Base64.getDecoder().decode(cipherB64);
    //    byte[] iv   = Arrays.copyOf(blob, 12);
    //    byte[] ct   = Arrays.copyOfRange(blob, 12, blob.length);
    //    byte[] key  = Base64.getDecoder().decode(keyB64);
    //    Cipher c    = Cipher.getInstance("AES/GCM/NoPadding");
    //    c.init(DECRYPT_MODE, new SecretKeySpec(key,"AES"),
    //                         new GCMParameterSpec(128, iv));
    //    return new String(c.doFinal(ct), StandardCharsets.UTF_8);
    // ────────────────────────────────────────────────────────────────────────
    private fun buildAesDecryptMethod(): MethodNode {
        val mn = MethodNode(
            ACC_PUBLIC or ACC_STATIC or ACC_SYNTHETIC,
            "aesDecrypt",
            DECRYPT_DESC,
            null,
            arrayOf("java/lang/Exception")
        )
        val il = mn.instructions

        // ── 1. Base64 decoder ──
        il.add(MethodInsnNode(INVOKESTATIC,
            "java/util/Base64", "getDecoder",
            "()Ljava/util/Base64\$Decoder;", false))

        // ── 2. decode cipherB64 → blob ──
        il.add(VarInsnNode(ALOAD, 0))   // cipherB64
        il.add(MethodInsnNode(INVOKEVIRTUAL,
            "java/util/Base64\$Decoder", "decode",
            "(Ljava/lang/String;)[B", false))
        il.add(VarInsnNode(ASTORE, 2))  // blob

        // ── 3. iv = Arrays.copyOf(blob, 12) ──
        il.add(VarInsnNode(ALOAD, 2))
        il.add(IntInsnNode(BIPUSH, 12))
        il.add(MethodInsnNode(INVOKESTATIC,
            "java/util/Arrays", "copyOf", "([BI)[B", false))
        il.add(VarInsnNode(ASTORE, 3))  // iv

        // ── 4. ct = Arrays.copyOfRange(blob, 12, blob.length) ──
        il.add(VarInsnNode(ALOAD, 2))
        il.add(IntInsnNode(BIPUSH, 12))
        il.add(VarInsnNode(ALOAD, 2))
        il.add(InsnNode(ARRAYLENGTH))
        il.add(MethodInsnNode(INVOKESTATIC,
            "java/util/Arrays", "copyOfRange", "([BII)[B", false))
        il.add(VarInsnNode(ASTORE, 4))  // ct

        // ── 5. key = Base64.getDecoder().decode(keyB64) ──
        il.add(MethodInsnNode(INVOKESTATIC,
            "java/util/Base64", "getDecoder",
            "()Ljava/util/Base64\$Decoder;", false))
        il.add(VarInsnNode(ALOAD, 1))   // keyB64
        il.add(MethodInsnNode(INVOKEVIRTUAL,
            "java/util/Base64\$Decoder", "decode",
            "(Ljava/lang/String;)[B", false))
        il.add(VarInsnNode(ASTORE, 5))  // rawKey

        // ── 6. new SecretKeySpec(rawKey, "AES") ──
        il.add(TypeInsnNode(NEW, "javax/crypto/spec/SecretKeySpec"))
        il.add(InsnNode(DUP))
        il.add(VarInsnNode(ALOAD, 5))
        il.add(LdcInsnNode("AES"))
        il.add(MethodInsnNode(INVOKESPECIAL,
            "javax/crypto/spec/SecretKeySpec", "<init>",
            "([BLjava/lang/String;)V", false))
        il.add(VarInsnNode(ASTORE, 6))  // secretKey

        // ── 7. new GCMParameterSpec(128, iv) ──
        il.add(TypeInsnNode(NEW, "javax/crypto/spec/GCMParameterSpec"))
        il.add(InsnNode(DUP))
        il.add(IntInsnNode(SIPUSH, 128))
        il.add(VarInsnNode(ALOAD, 3))   // iv
        il.add(MethodInsnNode(INVOKESPECIAL,
            "javax/crypto/spec/GCMParameterSpec", "<init>",
            "(I[B)V", false))
        il.add(VarInsnNode(ASTORE, 7))  // gcmSpec

        // ── 8. Cipher c = Cipher.getInstance("AES/GCM/NoPadding") ──
        il.add(LdcInsnNode("AES/GCM/NoPadding"))
        il.add(MethodInsnNode(INVOKESTATIC,
            "javax/crypto/Cipher", "getInstance",
            "(Ljava/lang/String;)Ljavax/crypto/Cipher;", false))
        il.add(VarInsnNode(ASTORE, 8))  // cipher

        // ── 9. c.init(DECRYPT_MODE=2, key, gcmSpec) ──
        il.add(VarInsnNode(ALOAD, 8))
        il.add(InsnNode(ICONST_2))      // Cipher.DECRYPT_MODE = 2
        il.add(VarInsnNode(ALOAD, 6))   // secretKey (as Key)
        il.add(VarInsnNode(ALOAD, 7))   // gcmSpec (as AlgorithmParameterSpec)
        il.add(MethodInsnNode(INVOKEVIRTUAL,
            "javax/crypto/Cipher", "init",
            "(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V", false))

        // ── 10. byte[] plain = c.doFinal(ct) ──
        il.add(VarInsnNode(ALOAD, 8))
        il.add(VarInsnNode(ALOAD, 4))   // ct
        il.add(MethodInsnNode(INVOKEVIRTUAL,
            "javax/crypto/Cipher", "doFinal",
            "([B)[B", false))
        il.add(VarInsnNode(ASTORE, 9))  // plainBytes

        // ── 11. return new String(plain, StandardCharsets.UTF_8) ──
        il.add(TypeInsnNode(NEW, "java/lang/String"))
        il.add(InsnNode(DUP))
        il.add(VarInsnNode(ALOAD, 9))
        il.add(FieldInsnNode(GETSTATIC,
            "java/nio/charset/StandardCharsets", "UTF_8",
            "Ljava/nio/charset/Charset;"))
        il.add(MethodInsnNode(INVOKESPECIAL,
            "java/lang/String", "<init>",
            "([BLjava/nio/charset/Charset;)V", false))
        il.add(InsnNode(ARETURN))

        mn.maxLocals = 10
        mn.maxStack  = 5
        return mn
    }

    // ────────────────────────────────────────────────────────────────────────
    //  bootstrapDecrypt(Lookup, name, type, cipherB64, keyB64): CallSite
    //
    //  Called once per call-site by the JVM's InvokeDynamic machinery.
    //  Returns a ConstantCallSite backed by a MethodHandle that, when invoked,
    //  calls aesDecrypt(cipherB64, keyB64) and returns the plaintext String.
    //
    //  Because BSM args are constant-pool entries, the cipher+key are baked
    //  into the bytecode but only decoded at the moment the call-site is
    //  first linked — no persistent cache, no static field.
    // ────────────────────────────────────────────────────────────────────────
    private fun buildBootstrapMethod(): MethodNode {
        val mn = MethodNode(
            ACC_PUBLIC or ACC_STATIC or ACC_SYNTHETIC,
            "bootstrapDecrypt",
            BOOTSTRAP_DESC,
            null,
            arrayOf("java/lang/Exception")
        )
        val il = mn.instructions

        //  params: 0=Lookup, 1=name(String), 2=MethodType, 3=cipherB64, 4=keyB64

        // ── 1. plain = aesDecrypt(cipherB64, keyB64) ──
        il.add(VarInsnNode(ALOAD, 3))   // cipherB64
        il.add(VarInsnNode(ALOAD, 4))   // keyB64
        il.add(MethodInsnNode(INVOKESTATIC,
            RUNTIME_CLASS, "aesDecrypt", DECRYPT_DESC, false))
        il.add(VarInsnNode(ASTORE, 5))  // plaintext

        // ── 2. mh = MethodHandles.constant(String.class, plain) ──
        il.add(LdcInsnNode(Type.getType("Ljava/lang/String;")))
        il.add(VarInsnNode(ALOAD, 5))
        il.add(MethodInsnNode(INVOKESTATIC,
            "java/lang/invoke/MethodHandles", "constant",
            "(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/invoke/MethodHandle;",
            false))
        il.add(VarInsnNode(ASTORE, 6))  // mh

        // ── 3. mh = mh.asType(type)  — match the call-site's MethodType ──
        il.add(VarInsnNode(ALOAD, 6))
        il.add(VarInsnNode(ALOAD, 2))   // MethodType from JVM
        il.add(MethodInsnNode(INVOKEVIRTUAL,
            "java/lang/invoke/MethodHandle", "asType",
            "(Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/MethodHandle;",
            false))
        il.add(VarInsnNode(ASTORE, 6))

        // ── 4. return new ConstantCallSite(mh) ──
        il.add(TypeInsnNode(NEW, "java/lang/invoke/ConstantCallSite"))
        il.add(InsnNode(DUP))
        il.add(VarInsnNode(ALOAD, 6))
        il.add(MethodInsnNode(INVOKESPECIAL,
            "java/lang/invoke/ConstantCallSite", "<init>",
            "(Ljava/lang/invoke/MethodHandle;)V", false))
        il.add(InsnNode(ARETURN))

        mn.maxLocals = 7
        mn.maxStack  = 3
        return mn
    }
}


// ─── 3. Integration helper — patch call-sites in target methods ─────────────

object AesStringPatcher {

    /**
     * Replace each [LdcInsnNode] carrying a plain String with an
     * INVOKEDYNAMIC that decrypts the string lazily via AES-256-GCM.
     *
     * Usage (from your StringObfuscator.process()):
     *
     *   val encList = mutableListOf<AesEncryptedString>()
     *   var idx = 0
     *   for (insn in method.instructions.toList()) {
     *       if (insn is LdcInsnNode && insn.cst is String) {
     *           val enc = AesStringEncryptor.encryptString(
     *               insn.cst as String, classNode.name, method.name, idx++,
     *               classNode, method, insn)
     *           encList.add(enc)
     *       }
     *   }
     *   // After decryptorClass is written to passThrough:
     *   AesStringPatcher.patchAll(encList)
     */
    fun patchAll(strings: List<AesEncryptedString>, decryptorClassName: String) {
        val bsmHandle = Handle(
            H_INVOKESTATIC,
            decryptorClassName,
            "bootstrapDecrypt",
            AesDecryptorClassGenerator.BOOTSTRAP_DESC,
            false
        )

        for (enc in strings) {
            val method = enc.methodNode

            // Build the INVOKEDYNAMIC node
            // name = obfuscated (empty / random), desc = "()Ljava/lang/String;"
            // BSM extra args: cipherB64 (String), keyB64 (String)
            val indy = InvokeDynamicInsnNode(
                /* name  */ "\u0000",          // deliberately unprintable
                /* desc  */ "()Ljava/lang/String;",
                /* bsm   */ bsmHandle,
                /* args  */ enc.cipherB64,     // BSM static arg 0
                            enc.keyB64         // BSM static arg 1
            )

            // Replace LDC with INVOKEDYNAMIC
            method.instructions.set(enc.insn, indy)
        }
    }
}
